var annotated_dup =
[
    [ "MD_Cubo", "class_m_d___cubo.html", "class_m_d___cubo" ],
    [ "MD_Cubo_72xx", "class_m_d___cubo__72xx.html", "class_m_d___cubo__72xx" ],
    [ "MD_Cubo_ICS595", "class_m_d___cubo___i_c_s595.html", "class_m_d___cubo___i_c_s595" ],
    [ "MD_Cubo_JC", "class_m_d___cubo___j_c.html", "class_m_d___cubo___j_c" ]
];