var class_m_d___cubo__72xx =
[
    [ "MD_Cubo_72xx", "class_m_d___cubo__72xx.html#ab744b32092f6a26ec57d489a69455117", null ],
    [ "~MD_Cubo_72xx", "class_m_d___cubo__72xx.html#ade84c71e223d8c11ef0da317dca97e18", null ],
    [ "begin", "class_m_d___cubo__72xx.html#a9ff6a08667d2d577588b6f6d7c208355", null ],
    [ "clear", "class_m_d___cubo__72xx.html#a4043b5ac324acb055b060a1df49f3b60", null ],
    [ "getVoxel", "class_m_d___cubo__72xx.html#a2c8f4c7f0346fe562e210429ecdea044", null ],
    [ "setIntensity", "class_m_d___cubo__72xx.html#ae618be8290e45ffcfa37ede4bc2d4458", null ],
    [ "setVoxel", "class_m_d___cubo__72xx.html#ad6eef37e70705bc7bf2c40a21d4b0e86", null ],
    [ "size", "class_m_d___cubo__72xx.html#a748d56f2600ecf9936e5caba8374259c", null ],
    [ "update", "class_m_d___cubo__72xx.html#abcfbb6848d45a41646290f78cab66f9f", null ]
];