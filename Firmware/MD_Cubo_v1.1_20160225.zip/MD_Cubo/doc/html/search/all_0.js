var searchData=
[
  ['_5fsizexaxis',['_sizeXaxis',['../class_m_d___cubo.html#a06e5e9b0165c1cc9c1425aa3ab932da0',1,'MD_Cubo']]],
  ['_5fsizeyaxis',['_sizeYaxis',['../class_m_d___cubo.html#a004b38bd2214466fa55ccb80504a9888',1,'MD_Cubo']]],
  ['_5fsizezaxis',['_sizeZaxis',['../class_m_d___cubo.html#ab752cbc13a10241bba16e29eb1e83b72',1,'MD_Cubo']]]
];
