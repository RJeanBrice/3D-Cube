var searchData=
[
  ['animate',['animate',['../class_m_d___cubo.html#ae5bf797b8247375ee873f926ce4cc8c6',1,'MD_Cubo::animate()'],['../class_m_d___cubo___i_c_s595.html#af06c1d90659354cf42448e7053a070d5',1,'MD_Cubo_ICS595::animate()']]],
  ['array_5fsize',['ARRAY_SIZE',['../_m_d___cubo_8h.html#a25f003de16c08a4888b69f619d70f427',1,'MD_Cubo.h']]],
  ['axis_5ft',['axis_t',['../class_m_d___cubo.html#a5b4e3c95550d679303a932bc32427380',1,'MD_Cubo']]],
  ['arduino_20led_20cube_20library',['Arduino LED Cube Library',['../index.html',1,'']]],
  ['adding_20new_20cube_20types',['Adding New Cube Types',['../pageAddHardware.html',1,'index']]]
];
