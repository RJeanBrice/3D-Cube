var searchData=
[
  ['xaxis',['XAXIS',['../class_m_d___cubo.html#a5b4e3c95550d679303a932bc32427380a52951ccb86b709695da1e56f230b951d',1,'MD_Cubo']]],
  ['xyplane',['XYPLANE',['../class_m_d___cubo.html#a5e58e81576191fd4faac158ad4f4c1f7ab6d3e46ed40d34a4f42baf152ea3bcbd',1,'MD_Cubo']]],
  ['xzplane',['XZPLANE',['../class_m_d___cubo.html#a5e58e81576191fd4faac158ad4f4c1f7a37576ce80e400be4071ac1441cb99755',1,'MD_Cubo']]]
];
