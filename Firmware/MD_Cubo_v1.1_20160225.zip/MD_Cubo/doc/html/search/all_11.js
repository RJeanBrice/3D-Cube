var searchData=
[
  ['yaxis',['YAXIS',['../class_m_d___cubo.html#a5b4e3c95550d679303a932bc32427380ab8690fd20c21cd6aee8903c35ff5d803',1,'MD_Cubo']]],
  ['yzplane',['YZPLANE',['../class_m_d___cubo.html#a5e58e81576191fd4faac158ad4f4c1f7ab325d32f2cfb75d4213793c0b3929294',1,'MD_Cubo']]]
];
