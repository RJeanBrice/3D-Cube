var searchData=
[
  ['getvoxel',['getVoxel',['../class_m_d___cubo.html#a2a685982cc79b3f89910b8649e6af75f',1,'MD_Cubo::getVoxel()'],['../class_m_d___cubo__72xx.html#a2c8f4c7f0346fe562e210429ecdea044',1,'MD_Cubo_72xx::getVoxel()'],['../class_m_d___cubo___i_c_s595.html#af29ee7c00e5e97690ff4589a258a8917',1,'MD_Cubo_ICS595::getVoxel()'],['../class_m_d___cubo___j_c.html#ac44849db084d8f7cac2e91fbb861cd13',1,'MD_Cubo_JC::getVoxel()']]]
];
