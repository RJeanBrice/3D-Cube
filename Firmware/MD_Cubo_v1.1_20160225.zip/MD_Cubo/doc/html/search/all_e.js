var searchData=
[
  ['test_5fmode',['TEST_MODE',['../_m_d___cubo__4x4__72xx_8h.html#ab6d58cce6e97b6b549801e696ac9f4f6',1,'TEST_MODE():&#160;MD_Cubo_4x4_72xx.h'],['../_m_d___cubo__8x8__j_c_8h.html#ab6d58cce6e97b6b549801e696ac9f4f6',1,'TEST_MODE():&#160;MD_Cubo_8x8_jC.h']]]
];
