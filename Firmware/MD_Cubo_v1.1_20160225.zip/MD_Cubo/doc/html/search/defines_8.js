var searchData=
[
  ['scan_5fdigits',['SCAN_DIGITS',['../_m_d___cubo__4x4__72xx_8h.html#ae76157fec28d3c1f592d69cf04e2d28e',1,'SCAN_DIGITS():&#160;MD_Cubo_4x4_72xx.h'],['../_m_d___cubo__8x8__j_c_8h.html#ae76157fec28d3c1f592d69cf04e2d28e',1,'SCAN_DIGITS():&#160;MD_Cubo_8x8_jC.h']]]
];
