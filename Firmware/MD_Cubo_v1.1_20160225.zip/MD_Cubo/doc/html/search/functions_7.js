var searchData=
[
  ['setintensity',['setIntensity',['../class_m_d___cubo.html#a553c2a2911b46e4a413f2076c1cc2025',1,'MD_Cubo::setIntensity()'],['../class_m_d___cubo__72xx.html#ae618be8290e45ffcfa37ede4bc2d4458',1,'MD_Cubo_72xx::setIntensity()'],['../class_m_d___cubo___j_c.html#a8054e813353531a38448ff0f3113dfa3',1,'MD_Cubo_JC::setIntensity()']]],
  ['setvoxel',['setVoxel',['../class_m_d___cubo.html#af36b312efe151ba8dfa6896ac438d062',1,'MD_Cubo::setVoxel()'],['../class_m_d___cubo__72xx.html#ad6eef37e70705bc7bf2c40a21d4b0e86',1,'MD_Cubo_72xx::setVoxel()'],['../class_m_d___cubo___i_c_s595.html#af34182d3be0d324755ddf2a64613e22a',1,'MD_Cubo_ICS595::setVoxel()'],['../class_m_d___cubo___j_c.html#a381e8da0ab24903ff62aa8c978a0b724',1,'MD_Cubo_JC::setVoxel()']]],
  ['size',['size',['../class_m_d___cubo.html#a0063c6074ac90e87ac1fb7eec2e76da9',1,'MD_Cubo::size()'],['../class_m_d___cubo__72xx.html#a748d56f2600ecf9936e5caba8374259c',1,'MD_Cubo_72xx::size()'],['../class_m_d___cubo___i_c_s595.html#a1eeac5bac564443ef0598c86814e3eb9',1,'MD_Cubo_ICS595::size()'],['../class_m_d___cubo___j_c.html#a7201deb486e5ffd0aa9b82342d024610',1,'MD_Cubo_JC::size()']]]
];
