var pageHardware =
[
    [ "Parola Custom Module", "pageParola.html", null ],
    [ "Generic Module", "pageGeneric.html", null ],
    [ "ICStation Module", "pageICStation.html", null ],
    [ "FC-16 Module", "pageFC16.html", null ],
    [ "New Hardware Types", "pageNewHardware.html", null ]
];