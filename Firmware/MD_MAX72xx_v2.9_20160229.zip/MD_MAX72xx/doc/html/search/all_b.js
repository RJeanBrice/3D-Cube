var searchData=
[
  ['new_20hardware_20types',['New Hardware Types',['../pageNewHardware.html',1,'pageHardware']]]
];
