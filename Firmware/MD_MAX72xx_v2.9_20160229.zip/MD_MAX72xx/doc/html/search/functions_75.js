var searchData=
[
  ['update',['update',['../class_m_d___m_a_x72_x_x.html#adb5d9e093d7381bae06666d495fdf5a8',1,'MD_MAX72XX::update(controlValue_t mode)'],['../class_m_d___m_a_x72_x_x.html#a4d51360880d7a6fa33a6f917cf423879',1,'MD_MAX72XX::update(void)'],['../class_m_d___m_a_x72_x_x.html#a08cbd63b5b0853ec25b08742b502e46e',1,'MD_MAX72XX::update(uint8_t buf)']]]
];
