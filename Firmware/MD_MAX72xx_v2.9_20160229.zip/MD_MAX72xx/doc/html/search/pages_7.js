var searchData=
[
  ['parola_20custom_20module',['Parola Custom Module',['../pageParola.html',1,'pageHardware']]]
];
